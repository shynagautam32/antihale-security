from __future__ import annotations

import queue
import os
import platform
import subprocess
import threading
from pathlib import Path
from tkinter import BOTH, END, LEFT, RIGHT, TOP, VERTICAL, BooleanVar, StringVar, Tk, filedialog, messagebox
from tkinter import ttk

from .defender import DefenderBridge, DefenderResult
from .quarantine import QuarantineStore
from .scanner import Finding, NimbravaxScanner, ScanOptions, ScanSummary


APP_NAME = "AntiHale Antivirus"
BG = "#06261d"
PANEL = "#0b3a2d"
PANEL_LIGHT = "#10533f"
ACCENT = "#34d399"
WHITE = "#f7fffb"
MUTED = "#c9ded6"
WARNING = "#fbbf24"
DANGER = "#fb7185"


class NimbravaxApp:
    def __init__(self, root: Tk) -> None:
        self.root = root
        self.root.title(APP_NAME)
        self.root.geometry("1120x720")
        self.root.minsize(980, 640)
        self.root.configure(bg=BG)

        self.events: queue.Queue[tuple[str, object]] = queue.Queue()
        self.status = StringVar(value="Ready")
        self.current_file = StringVar(value="No scan running")
        self.auto_quarantine = BooleanVar(value=True)
        self.scan_running = False

        self.defender = DefenderBridge()
        self.quarantine = QuarantineStore()
        self.scanner = NimbravaxScanner(quarantine_store=self.quarantine)

        self._configure_styles()
        self._build_layout()
        self._refresh_defender_status()
        self._poll_events()

    def _configure_styles(self) -> None:
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Root.TFrame", background=BG)
        style.configure("Panel.TFrame", background=PANEL)
        style.configure("Card.TFrame", background=PANEL_LIGHT)
        style.configure("Title.TLabel", background=BG, foreground=WHITE, font=("Segoe UI", 26, "bold"))
        style.configure("Subtitle.TLabel", background=BG, foreground=MUTED, font=("Segoe UI", 11))
        style.configure("PanelTitle.TLabel", background=PANEL, foreground=WHITE, font=("Segoe UI", 14, "bold"))
        style.configure("CardTitle.TLabel", background=PANEL_LIGHT, foreground=WHITE, font=("Segoe UI", 11, "bold"))
        style.configure("Text.TLabel", background=PANEL, foreground=MUTED, font=("Segoe UI", 10))
        style.configure("CardText.TLabel", background=PANEL_LIGHT, foreground=MUTED, font=("Segoe UI", 10))
        style.configure("Primary.TButton", font=("Segoe UI", 10, "bold"), padding=(14, 10), background=ACCENT, foreground="#052016")
        style.map("Primary.TButton", background=[("active", "#6ee7b7"), ("disabled", "#4b6b5f")])
        style.configure("Secondary.TButton", font=("Segoe UI", 10), padding=(12, 9), background=PANEL_LIGHT, foreground=WHITE)
        style.map("Secondary.TButton", background=[("active", "#17634c"), ("disabled", "#33433d")])
        style.configure("TCheckbutton", background=PANEL, foreground=WHITE, font=("Segoe UI", 10))
        style.map("TCheckbutton", background=[("active", PANEL)], foreground=[("disabled", MUTED)])
        style.configure("Treeview", background="#f8fffb", foreground="#10231c", fieldbackground="#f8fffb", rowheight=30, font=("Segoe UI", 10))
        style.configure("Treeview.Heading", background="#dff5ec", foreground="#0b2c21", font=("Segoe UI", 10, "bold"))
        style.configure("Vertical.TScrollbar", background=PANEL_LIGHT, troughcolor=PANEL)

    def _build_layout(self) -> None:
        shell = ttk.Frame(self.root, style="Root.TFrame", padding=24)
        shell.pack(fill=BOTH, expand=True)

        header = ttk.Frame(shell, style="Root.TFrame")
        header.pack(fill="x", side=TOP)
        ttk.Label(header, text=APP_NAME, style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            header,
            text="Lightweight Windows protection powered by Microsoft Defender and local quarantine scanning",
            style="Subtitle.TLabel",
        ).pack(anchor="w", pady=(4, 18))

        content = ttk.Frame(shell, style="Root.TFrame")
        content.pack(fill=BOTH, expand=True)

        sidebar = ttk.Frame(content, style="Panel.TFrame", padding=18)
        sidebar.pack(side=LEFT, fill="y", padx=(0, 18))

        ttk.Label(sidebar, text="Protection", style="PanelTitle.TLabel").pack(anchor="w", pady=(0, 12))
        self.quick_button = ttk.Button(sidebar, text="Quick Scan", style="Primary.TButton", command=self.quick_scan)
        self.quick_button.pack(fill="x", pady=5)
        self.full_button = ttk.Button(sidebar, text="Full Scan", style="Secondary.TButton", command=self.full_scan)
        self.full_button.pack(fill="x", pady=5)
        self.custom_button = ttk.Button(sidebar, text="Scan Folder", style="Secondary.TButton", command=self.custom_scan)
        self.custom_button.pack(fill="x", pady=5)
        self.remove_button = ttk.Button(sidebar, text="Remove Defender Threats", style="Secondary.TButton", command=self.remove_threats)
        self.remove_button.pack(fill="x", pady=(5, 18))
        ttk.Checkbutton(sidebar, text="Auto quarantine detections", variable=self.auto_quarantine).pack(anchor="w", pady=(4, 18))

        ttk.Label(sidebar, text="System Status", style="PanelTitle.TLabel").pack(anchor="w", pady=(8, 10))
        self.defender_status = ttk.Label(sidebar, text="Checking Defender...", style="Text.TLabel", wraplength=250, justify=LEFT)
        self.defender_status.pack(anchor="w", pady=(0, 18))
        ttk.Button(sidebar, text="Open Quarantine Folder", style="Secondary.TButton", command=self.open_quarantine).pack(fill="x", pady=5)

        main = ttk.Frame(content, style="Root.TFrame")
        main.pack(side=RIGHT, fill=BOTH, expand=True)

        cards = ttk.Frame(main, style="Root.TFrame")
        cards.pack(fill="x", pady=(0, 18))
        self.scanned_card = self._metric_card(cards, "Files scanned", "0")
        self.findings_card = self._metric_card(cards, "Findings", "0")
        self.quarantine_card = self._metric_card(cards, "Quarantined", "0")

        activity = ttk.Frame(main, style="Panel.TFrame", padding=16)
        activity.pack(fill="x", pady=(0, 18))
        ttk.Label(activity, textvariable=self.status, style="PanelTitle.TLabel").pack(anchor="w")
        ttk.Label(activity, textvariable=self.current_file, style="Text.TLabel", wraplength=720).pack(anchor="w", pady=(6, 0))

        table_panel = ttk.Frame(main, style="Panel.TFrame", padding=14)
        table_panel.pack(fill=BOTH, expand=True)
        ttk.Label(table_panel, text="Detections", style="PanelTitle.TLabel").pack(anchor="w", pady=(0, 10))

        table_wrap = ttk.Frame(table_panel, style="Panel.TFrame")
        table_wrap.pack(fill=BOTH, expand=True)
        columns = ("severity", "threat", "source", "action", "path")
        self.findings_tree = ttk.Treeview(table_wrap, columns=columns, show="headings")
        for column, width in {
            "severity": 95,
            "threat": 230,
            "source": 150,
            "action": 130,
            "path": 420,
        }.items():
            self.findings_tree.heading(column, text=column.title())
            self.findings_tree.column(column, width=width, anchor="w")
        scrollbar = ttk.Scrollbar(table_wrap, orient=VERTICAL, command=self.findings_tree.yview)
        self.findings_tree.configure(yscrollcommand=scrollbar.set)
        self.findings_tree.pack(side=LEFT, fill=BOTH, expand=True)
        scrollbar.pack(side=RIGHT, fill="y")

    def _metric_card(self, parent: ttk.Frame, title: str, value: str) -> StringVar:
        card = ttk.Frame(parent, style="Card.TFrame", padding=16)
        card.pack(side=LEFT, fill="x", expand=True, padx=(0, 12))
        ttk.Label(card, text=title, style="CardText.TLabel").pack(anchor="w")
        var = StringVar(value=value)
        ttk.Label(card, textvariable=var, style="CardTitle.TLabel", font=("Segoe UI", 22, "bold")).pack(anchor="w", pady=(4, 0))
        return var

    def quick_scan(self) -> None:
        paths = self._common_user_paths()
        self._start_scan("Quick scan", paths, defender_action=self.defender.quick_scan)

    def full_scan(self) -> None:
        self._start_scan("Full scan", [Path.home()], defender_action=self.defender.full_scan)

    def custom_scan(self) -> None:
        folder = filedialog.askdirectory(title="Choose a folder to scan")
        if not folder:
            return
        selected = Path(folder)
        self._start_scan("Custom folder scan", [selected], defender_action=lambda: self.defender.custom_scan(selected))

    def remove_threats(self) -> None:
        if self.scan_running:
            return
        self.status.set("Removing Defender threats...")
        self._run_worker(lambda: self.events.put(("defender", self.defender.remove_threats())))

    def open_quarantine(self) -> None:
        self.quarantine.root.mkdir(parents=True, exist_ok=True)
        try:
            system = platform.system().lower()
            if system == "windows":
                os.startfile(self.quarantine.root)  # type: ignore[attr-defined]
            elif system == "darwin":
                subprocess.run(["open", str(self.quarantine.root)], check=False)
            else:
                subprocess.run(["xdg-open", str(self.quarantine.root)], check=False)
        except OSError:
            messagebox.showinfo("Quarantine", f"Quarantine folder:\n{self.quarantine.root}")

    def _start_scan(self, label: str, paths: list[Path], defender_action=None) -> None:
        if self.scan_running:
            return
        self.scan_running = True
        self._set_buttons(False)
        self._clear_findings()
        self.status.set(f"{label} running...")
        self.current_file.set("Starting scanner")

        def work() -> None:
            if defender_action:
                self.events.put(("defender", defender_action()))
            summary = self.scanner.scan_paths(
                paths,
                ScanOptions(auto_quarantine=self.auto_quarantine.get()),
                on_progress=lambda path: self.events.put(("progress", path)),
                on_finding=lambda finding: self.events.put(("finding", finding)),
            )
            self.events.put(("summary", summary))

        self._run_worker(work)

    def _run_worker(self, target) -> None:
        thread = threading.Thread(target=target, daemon=True)
        thread.start()

    def _poll_events(self) -> None:
        try:
            while True:
                event, payload = self.events.get_nowait()
                if event == "progress":
                    self.current_file.set(str(payload))
                elif event == "finding":
                    self._add_finding(payload)
                elif event == "summary":
                    self._finish_scan(payload)
                elif event == "defender":
                    self._show_defender_result(payload)
                elif event == "status_result":
                    self._render_defender_status(payload)
        except queue.Empty:
            pass
        self.root.after(120, self._poll_events)

    def _add_finding(self, finding: Finding) -> None:
        self.findings_tree.insert(
            "",
            END,
            values=(finding.severity, finding.threat_name, finding.source, finding.action, finding.path),
        )

    def _finish_scan(self, summary: ScanSummary) -> None:
        self.scanned_card.set(str(summary.scanned_files))
        self.findings_card.set(str(summary.findings))
        self.quarantine_card.set(str(summary.quarantined))
        self.status.set("Scan complete" if summary.findings == 0 else "Scan complete with detections")
        self.current_file.set(
            f"Scanned {summary.scanned_files} files, skipped {summary.skipped_files}, errors {summary.errors}."
        )
        self.scan_running = False
        self._set_buttons(True)

    def _show_defender_result(self, result: DefenderResult) -> None:
        if result.success:
            self.status.set(result.message)
        elif result.available:
            self.status.set("Defender action needs attention")
            self.current_file.set(result.message)
        else:
            self.current_file.set(result.message)

    def _refresh_defender_status(self) -> None:
        def work() -> None:
            result = self.defender.get_status()
            self.events.put(("status_result", result))

        threading.Thread(target=work, daemon=True).start()

    def _render_defender_status(self, result: DefenderResult) -> None:
        if not result.success or not isinstance(result.data, dict):
            self.defender_status.configure(text=result.message)
            return
        enabled = result.data.get("AntivirusEnabled")
        realtime = result.data.get("RealTimeProtectionEnabled")
        updated = result.data.get("AntivirusSignatureLastUpdated")
        self.defender_status.configure(
            text=f"Antivirus enabled: {enabled}\nReal-time protection: {realtime}\nSignatures: {updated}"
        )

    def _set_buttons(self, enabled: bool) -> None:
        state = "normal" if enabled else "disabled"
        for button in (self.quick_button, self.full_button, self.custom_button, self.remove_button):
            button.configure(state=state)

    def _clear_findings(self) -> None:
        for item in self.findings_tree.get_children():
            self.findings_tree.delete(item)
        self.scanned_card.set("0")
        self.findings_card.set("0")
        self.quarantine_card.set("0")

    def _common_user_paths(self) -> list[Path]:
        home = Path.home()
        candidates = [home / "Desktop", home / "Downloads", home / "Documents"]
        existing = [path for path in candidates if path.exists()]
        return existing or [home]


def main() -> None:
    root = Tk()
    NimbravaxApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
