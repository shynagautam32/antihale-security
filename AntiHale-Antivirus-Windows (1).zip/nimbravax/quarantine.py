from __future__ import annotations

import json
import os
import shutil
import uuid
from dataclasses import asdict, is_dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def default_quarantine_dir() -> Path:
    for base in (
        os.environ.get("ANTIHALE_QUARANTINE"),
        os.environ.get("NIMBRAVAX_QUARANTINE"),
        os.environ.get("LOCALAPPDATA"),
        os.environ.get("APPDATA"),
        os.environ.get("ProgramData"),
    ):
        if base:
            return Path(base) / "AntiHale Antivirus" / "Quarantine"
    return Path.home() / ".antihale" / "quarantine"


class QuarantineStore:
    def __init__(self, root: Path | None = None) -> None:
        self.root = root or default_quarantine_dir()
        try:
            self.root.mkdir(parents=True, exist_ok=True)
        except OSError:
            self.root = Path.cwd() / ".antihale" / "quarantine"
            self.root.mkdir(parents=True, exist_ok=True)

    def quarantine(self, file_path: Path, finding: Any) -> Path:
        file_path = file_path.resolve()
        if not file_path.is_file():
            raise FileNotFoundError(str(file_path))

        quarantine_id = uuid.uuid4().hex
        payload_path = self.root / f"{quarantine_id}.quarantined"
        metadata_path = self.root / f"{quarantine_id}.json"

        shutil.move(str(file_path), str(payload_path))

        metadata = {
            "id": quarantine_id,
            "original_path": str(file_path),
            "quarantined_path": str(payload_path),
            "quarantined_at": datetime.now(timezone.utc).isoformat(),
            "finding": asdict(finding) if is_dataclass(finding) else finding,
        }
        metadata_path.write_text(json.dumps(metadata, indent=2), encoding="utf-8")
        return payload_path

    def list_items(self) -> list[dict[str, Any]]:
        items: list[dict[str, Any]] = []
        for metadata_path in sorted(self.root.glob("*.json")):
            try:
                items.append(json.loads(metadata_path.read_text(encoding="utf-8")))
            except (OSError, json.JSONDecodeError):
                continue
        return items
