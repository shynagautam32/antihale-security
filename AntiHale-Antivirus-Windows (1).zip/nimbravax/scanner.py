from __future__ import annotations

import hashlib
import json
import math
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable

from .quarantine import QuarantineStore


ProgressCallback = Callable[[str], None]
FindingCallback = Callable[["Finding"], None]


@dataclass
class Finding:
    path: str
    threat_name: str
    severity: str
    source: str
    action: str
    details: str


@dataclass
class ScanSummary:
    scanned_files: int = 0
    skipped_files: int = 0
    findings: int = 0
    quarantined: int = 0
    errors: int = 0


@dataclass
class ScanOptions:
    auto_quarantine: bool = True
    max_file_size_mb: int = 100


class SignatureDatabase:
    def __init__(self, hashes: dict[str, dict], script_markers: list[dict]) -> None:
        self.hashes = {key.lower(): value for key, value in hashes.items()}
        self.script_markers = script_markers

    @classmethod
    def load_default(cls) -> "SignatureDatabase":
        path = Path(__file__).with_name("signatures.json")
        data = json.loads(path.read_text(encoding="utf-8"))
        return cls(data.get("hashes", {}), data.get("suspicious_script_markers", []))


class NimbravaxScanner:
    executable_extensions = {
        ".exe",
        ".dll",
        ".scr",
        ".com",
        ".pif",
        ".bat",
        ".cmd",
        ".ps1",
        ".vbs",
        ".js",
        ".jse",
        ".wsf",
        ".hta",
        ".msi",
    }
    script_extensions = {".ps1", ".bat", ".cmd", ".vbs", ".js", ".jse", ".wsf", ".hta"}
    document_extensions = {".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".txt", ".jpg", ".png"}
    skipped_dirs = {
        "$recycle.bin",
        "system volume information",
        "windows\\winsxs",
        "windows\\servicing",
        "appdata\\local\\packages",
        "node_modules",
        ".git",
    }

    def __init__(
        self,
        signatures: SignatureDatabase | None = None,
        quarantine_store: QuarantineStore | None = None,
    ) -> None:
        self.signatures = signatures or SignatureDatabase.load_default()
        self.quarantine_store = quarantine_store or QuarantineStore()

    def scan_paths(
        self,
        paths: Iterable[Path],
        options: ScanOptions | None = None,
        on_progress: ProgressCallback | None = None,
        on_finding: FindingCallback | None = None,
    ) -> ScanSummary:
        options = options or ScanOptions()
        summary = ScanSummary()
        max_size = options.max_file_size_mb * 1024 * 1024

        for file_path in self._walk_files(paths):
            try:
                stat = file_path.stat()
            except OSError:
                summary.errors += 1
                continue

            if stat.st_size > max_size:
                summary.skipped_files += 1
                continue

            if on_progress:
                on_progress(str(file_path))

            try:
                findings = self._scan_file(file_path, stat.st_size)
            except OSError:
                summary.errors += 1
                continue

            summary.scanned_files += 1

            for finding in findings:
                summary.findings += 1
                if options.auto_quarantine and self._should_quarantine(finding):
                    try:
                        self.quarantine_store.quarantine(file_path, finding)
                        finding.action = "Quarantined"
                        summary.quarantined += 1
                    except OSError as exc:
                        finding.action = "Quarantine failed"
                        finding.details = f"{finding.details} ({exc})"
                        summary.errors += 1
                if on_finding:
                    on_finding(finding)
                break

        return summary

    def _walk_files(self, paths: Iterable[Path]) -> Iterable[Path]:
        for root in paths:
            root = root.expanduser()
            if root.is_file():
                yield root
                continue
            if not root.exists():
                continue
            for current_root, dirs, files in os.walk(root):
                current_lower = current_root.lower()
                dirs[:] = [
                    name
                    for name in dirs
                    if not self._is_skipped_dir(current_lower, name.lower())
                ]
                for name in files:
                    yield Path(current_root) / name

    def _is_skipped_dir(self, current_root: str, dirname: str) -> bool:
        combined = f"{current_root}\\{dirname}"
        return dirname in self.skipped_dirs or any(marker in combined for marker in self.skipped_dirs)

    def _scan_file(self, path: Path, size: int) -> list[Finding]:
        findings: list[Finding] = []
        digest = self._hash_file(path)
        suffix = path.suffix.lower()
        lower_name = path.name.lower()

        for hash_value in {digest["sha256"], digest["md5"]}:
            match = self.signatures.hashes.get(hash_value)
            if match:
                findings.append(
                    Finding(
                        path=str(path),
                        threat_name=match.get("name", "Known malware signature"),
                        severity=match.get("severity", "High"),
                        source="Signature hash",
                        action="Detected",
                        details=match.get("description", f"Matched hash {hash_value}."),
                    )
                )
                return findings

        if suffix in self.script_extensions:
            findings.extend(self._scan_script_markers(path))

        if suffix in self.executable_extensions and self._has_double_extension(lower_name):
            findings.append(
                Finding(
                    path=str(path),
                    threat_name="Suspicious double-extension executable",
                    severity="High",
                    source="Heuristic",
                    action="Detected",
                    details="Executable file is disguised as a document or image.",
                )
            )

        if suffix in {".exe", ".dll", ".scr"} and 0 < size <= 20 * 1024 * 1024:
            entropy = self._sample_entropy(path)
            if entropy >= 7.65:
                findings.append(
                    Finding(
                        path=str(path),
                        threat_name="Suspicious packed executable",
                        severity="Medium",
                        source="Heuristic",
                        action="Review required",
                        details=f"High byte entropy detected ({entropy:.2f}).",
                    )
                )

        return findings

    def _hash_file(self, path: Path) -> dict[str, str]:
        sha256 = hashlib.sha256()
        md5 = hashlib.md5(usedforsecurity=False)
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                sha256.update(chunk)
                md5.update(chunk)
        return {"sha256": sha256.hexdigest(), "md5": md5.hexdigest()}

    def _scan_script_markers(self, path: Path) -> list[Finding]:
        try:
            content = path.read_bytes()[:1024 * 1024].decode("utf-8", errors="ignore").lower()
        except OSError:
            return []

        findings: list[Finding] = []
        for marker in self.signatures.script_markers:
            marker_text = marker.get("marker", "").lower()
            if marker_text and marker_text in content:
                findings.append(
                    Finding(
                        path=str(path),
                        threat_name=marker.get("name", "Suspicious script behavior"),
                        severity=marker.get("severity", "High"),
                        source="Script heuristic",
                        action="Detected",
                        details=f"Matched suspicious command marker: {marker_text}.",
                    )
                )
        return findings

    def _has_double_extension(self, lower_name: str) -> bool:
        parts = lower_name.split(".")
        if len(parts) < 3:
            return False
        visible_extension = f".{parts[-2]}"
        final_extension = f".{parts[-1]}"
        return visible_extension in self.document_extensions and final_extension in self.executable_extensions

    def _sample_entropy(self, path: Path) -> float:
        with path.open("rb") as handle:
            data = handle.read(1024 * 1024)
        if not data:
            return 0.0
        counts = [0] * 256
        for byte in data:
            counts[byte] += 1
        length = len(data)
        return -sum((count / length) * math.log2(count / length) for count in counts if count)

    def _should_quarantine(self, finding: Finding) -> bool:
        return finding.severity in {"Critical", "High", "Test"} and finding.action == "Detected"

