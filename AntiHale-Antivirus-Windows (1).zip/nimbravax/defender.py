from __future__ import annotations

import json
import platform
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass
class DefenderResult:
    available: bool
    success: bool
    message: str
    data: Any = None


class DefenderBridge:
    def __init__(self) -> None:
        self.is_windows = platform.system().lower() == "windows"

    def get_status(self) -> DefenderResult:
        if not self.is_windows:
            return DefenderResult(False, False, "Microsoft Defender is only available on Windows.")
        command = "Get-MpComputerStatus | Select-Object AMServiceEnabled,AntivirusEnabled,RealTimeProtectionEnabled,AntivirusSignatureLastUpdated | ConvertTo-Json"
        return self._run_json(command, "Defender status loaded.")

    def quick_scan(self) -> DefenderResult:
        if not self.is_windows:
            return DefenderResult(False, False, "Quick scan skipped because this is not Windows.")
        return self._run("Start-MpScan -ScanType QuickScan", "Microsoft Defender quick scan completed.")

    def full_scan(self) -> DefenderResult:
        if not self.is_windows:
            return DefenderResult(False, False, "Full scan skipped because this is not Windows.")
        return self._run("Start-MpScan -ScanType FullScan", "Microsoft Defender full scan completed.")

    def custom_scan(self, path: Path) -> DefenderResult:
        if not self.is_windows:
            return DefenderResult(False, False, "Custom Defender scan skipped because this is not Windows.")
        escaped = str(path).replace("'", "''")
        return self._run(
            f"Start-MpScan -ScanType CustomScan -ScanPath '{escaped}'",
            "Microsoft Defender custom scan completed.",
        )

    def remove_threats(self) -> DefenderResult:
        if not self.is_windows:
            return DefenderResult(False, False, "Threat removal requires Windows Defender.")
        return self._run("Remove-MpThreat", "Microsoft Defender threat removal completed.")

    def latest_detections(self) -> DefenderResult:
        if not self.is_windows:
            return DefenderResult(False, False, "Defender detections are only available on Windows.")
        command = "Get-MpThreatDetection | Select-Object -First 25 | ConvertTo-Json -Depth 4"
        return self._run_json(command, "Latest Defender detections loaded.")

    def _run(self, command: str, success_message: str) -> DefenderResult:
        completed = subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", command],
            capture_output=True,
            text=True,
            check=False,
        )
        if completed.returncode == 0:
            return DefenderResult(True, True, success_message, completed.stdout.strip())
        message = completed.stderr.strip() or completed.stdout.strip() or "Defender command failed."
        return DefenderResult(True, False, message)

    def _run_json(self, command: str, success_message: str) -> DefenderResult:
        result = self._run(command, success_message)
        if not result.success:
            return result
        if not result.data:
            return DefenderResult(True, True, success_message, None)
        try:
            return DefenderResult(True, True, success_message, json.loads(result.data))
        except json.JSONDecodeError:
            return result

