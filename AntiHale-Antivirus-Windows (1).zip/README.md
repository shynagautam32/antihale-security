# AntiHale Antivirus

AntiHale Antivirus is a lightweight Windows antivirus-style desktop app with a dark green and white professional interface.

Important security note: no antivirus can honestly guarantee that it will find and remove every virus, ransomware family, trojan, or future malware strain. AntiHale Antivirus is built as a practical safety layer:

- Uses Microsoft Defender Antivirus on Windows for real malware scanning and remediation.
- Adds a local scanner for known bad hashes and high-confidence suspicious script behavior.
- Automatically quarantines high-confidence local detections instead of permanently deleting files.
- Runs scans in a background thread so the interface stays responsive.
- Avoids heavyweight always-on background services to reduce system slowdown.

## Name

The working product name is **AntiHale Antivirus**. A quick web check did not surface an antivirus, cybersecurity software product, or company using this exact name, but a formal trademark search is required before commercial release.

## Run On Windows

1. Install Python 3.11 or newer from python.org.
2. Open PowerShell in this folder.
3. Run:

```powershell
python -m nimbravax.app
```

For best remediation results, run PowerShell or the packaged app as Administrator. Microsoft Defender commands may be limited without elevated permissions.

## Build A Windows EXE

Run:

```powershell
.\packaging\build_windows.ps1
```

The packaged app will be created in `dist\AntiHale Antivirus\`.

## Website

A static website is available in `website/`. Open `website/index.html` in a browser to preview it, then publish the folder with GitHub Pages, Netlify, Vercel, or any standard web host.

The website is for product information and downloads. Virus scanning and malware removal must happen in the installed Windows app, not inside a browser.

## What It Can Do

- Quick scan: asks Microsoft Defender to run a quick scan, then checks common user folders.
- Full scan: asks Microsoft Defender to run a full scan, then checks the user profile.
- Custom folder scan: scans a folder you choose and asks Defender to scan it on Windows.
- Auto quarantine: moves high-confidence suspicious files into a quarantine folder with metadata.
- Remove Defender threats: calls Defender remediation through `Remove-MpThreat`.

## What It Does Not Claim

AntiHale Antivirus does not claim perfect detection, kernel-level protection, behavior monitoring, cloud reputation, exploit prevention, or enterprise EDR features. Those require a maintained malware research pipeline, signed drivers, cloud infrastructure, and continuous threat intelligence.
