$ErrorActionPreference = "Stop"

Set-Location -Path (Split-Path -Parent $PSScriptRoot)

if (-not (Test-Path ".venv")) {
    python -m venv .venv
}

& .\.venv\Scripts\python.exe -m pip install --upgrade pip pyinstaller
& .\.venv\Scripts\python.exe -m PyInstaller `
    --noconfirm `
    --windowed `
    --name "AntiHale Antivirus" `
    --add-data "nimbravax\signatures.json;nimbravax" `
    main.py

Write-Host "AntiHale Antivirus build complete: dist\AntiHale Antivirus\AntiHale Antivirus.exe"
