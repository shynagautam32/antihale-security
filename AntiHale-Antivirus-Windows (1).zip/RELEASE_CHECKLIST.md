# AntiHale Antivirus Release Checklist

## 1. Build The Windows App

On a Windows computer with Python installed:

```powershell
cd path\to\can-you-create-an-antivirus-app
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\packaging\build_windows.ps1
```

The app will be created here:

```powershell
dist\AntiHale Antivirus\AntiHale Antivirus.exe
```

## 2. Test On Windows

- Run the app normally.
- Run it again as Administrator.
- Test Quick Scan.
- Test Scan Folder.
- Test Remove Defender Threats.
- Confirm the quarantine folder is created.

## 3. Create A Download Package

Zip this folder:

```powershell
dist\AntiHale Antivirus
```

Recommended ZIP name:

```text
AntiHale-Antivirus-Windows.zip
```

This project also includes an automatic Windows build workflow:

```text
.github/workflows/windows-release.yml
```

To create a public download link on GitHub:

1. Push the project to GitHub.
2. Create and push a version tag, for example `v0.1.0`.
3. GitHub Actions will build the Windows ZIP.
4. GitHub Releases will publish `AntiHale-Antivirus-Windows.zip`.
5. Use the release asset URL as the download link on the website.

## 4. Code Sign Before Public Release

For public distribution, buy a Windows code-signing certificate and sign the `.exe`.
Unsigned security software often triggers browser and Windows warnings.

## 5. Publish The Website

The website files are in:

```text
website/
```

You can publish them with:

- GitHub Pages
- Netlify
- Vercel
- Any normal web hosting provider

This project includes a GitHub Pages workflow at `.github/workflows/pages.yml`.
After you push the project to GitHub, enable Pages with GitHub Actions as the source.

## 6. Add The Download Link

After uploading the ZIP or installer, update this link in `website/index.html`:

```html
<a class="button primary" href="#">Download coming soon</a>
```

Replace `#` with the real download URL.

## 7. Keep Claims Honest

Do not promise perfect detection or removal of every possible virus. Safer language:

```text
AntiHale Antivirus provides Defender-powered scanning, local suspicious-file detection, and automatic quarantine for high-confidence detections.
```
